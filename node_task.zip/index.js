/* eslint-disable no-undef */
const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const helmet = require("helmet");

const Routes = require("./routes");
const Constants = require("./src/helper/constants");

const routes = new Routes();

// create express app
const app = express();
app.use(helmet());

// config dotenv
dotenv.config();

const PORT = process.env.PORT || 4000;

app.all("/*", (req, res, next) => {

    // res.setHeader("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Request-Headers", "*");
    // tslint:disable-next-line: max-line-length
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,Access-Control-Allow-Headers, Authorization,X-L10N-Locale");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
    if (req.method === "OPTIONS") {
        res.writeHead(200);
        res.end();
    } else {
        next();
    }
});

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// parse requests of content-type - application/json
app.use(bodyParser.json());

app.use("/api", routes.path());

app.listen(PORT, () => {
    console.info(`${Constants.SERVER_STARTS} ${PORT}`);
});
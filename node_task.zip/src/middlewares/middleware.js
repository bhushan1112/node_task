const _ = require("lodash");

const Jwt = require("../helper/jwt");
const db = require("../DB/index");
const Constants = require("../helper/constants");
const { ErrorEnum } = require("../helper/messages");


const jwt = new Jwt();

module.exports = class Middleware {
    getUserAuthorized = async (
        req,
        res,
        next
    ) => {
        if (
            req.headers.authorization &&
            !_.isEmpty(req.headers.authorization)
        ) {
            try {
                const tokenInfo = jwt.decodeAuthToken(
                    req.headers.authorization.toString()
                );
                if (tokenInfo) {
                    const user = await db.users.findOne({ where: { id: tokenInfo } });
                    if (user) {
                        req.body._user = user.dataValues;
                        next();
                    } else {
                        res.status(Constants.UNAUTHORIZED_CODE).json({
                            error: ErrorEnum.ERR_UNAUTH,
                            code: Constants.UNAUTHORIZED_CODE,
                        });
                        return;
                    }
                } else {
                    res.status(Constants.UNAUTHORIZED_CODE).json({
                        error: ErrorEnum.ERR_UNAUTH,
                        code: Constants.UNAUTHORIZED_CODE,
                    });
                    return;
                }
            } catch (error) {
                res.status(Constants.INTERNAL_SERVER_ERROR_CODE).json({
                    error: ErrorEnum.ERR_INTERNAL_SERVER,
                    code: Constants.INTERNAL_SERVER_ERROR_CODE,
                });
                return;
            }
        } else {
            res.status(Constants.UNAUTHORIZED_CODE).json({
                error: ErrorEnum.ERR_UNAUTH,
                code: Constants.UNAUTHORIZED_CODE,
            });
            return;
        }
    };
};
const express = require("express");

const validate = require("../../middlewares/validate");
const ProductSchema = require("./ProductSchema");
const Middleware = require("../../middlewares/middleware");
const ProductController = require("./ProductController");

const router = express.Router();
const middleware = new Middleware();
const productController = new ProductController();

router.post("/", validate(ProductSchema.saveProduct), middleware.getUserAuthorized, productController.saveProduct);
router.get("/", validate(ProductSchema.getProducts),middleware.getUserAuthorized, productController.getProducts);
router.get("/:id", validate(ProductSchema.getProduct),middleware.getUserAuthorized, productController.getProductById);
router.put("/:id", validate(ProductSchema.updateProduct),middleware.getUserAuthorized, productController.updateProduct);
router.delete("/:id", validate(ProductSchema.deleteProduct),middleware.getUserAuthorized, productController.deleteProduct);

module.exports = router;
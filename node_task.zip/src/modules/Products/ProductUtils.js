const db = require("../../DB/index");
const { queryForSearch } = require("../../helper/common");
const { ErrorEnum } = require("../../helper/messages");

module.exports = class ProductUtils {
    saveProduct = async (product) => {
        const finaleObject = {
            productName: product.productName,
            category: product.category,
            priceBand: product.priceBand,

        };
        return db.product.create(finaleObject).then((res) => {
            return res;
        }).catch((err => {
            console.log(err);
            throw err;
        }));
    };

    getProducts = async (filters) => {
        if (filters.search) {
            filters.searchFields = ["productName", "category", "priceBand"];
        }
        const query = await queryForSearch(filters);
        if (!query.where) {
            query.where = {};
        }
        return db.product.findAndCountAll({
            col: "id",
            distinct: true,
            attributes: ["id", "productName", "category", "priceBand"],
            ...query
        }).then(products => {
            if (!products) {
                throw new Error(ErrorEnum.PRODUCTS_NOT_FOUND);
            }
            return products;
        });
    };

    getProductById = async (productId) => {
        return db.product
            .findOne({
                attributes: ["id", "productName", "category", "priceBand"],
                order: [
                    ["id", "desc"]
                ],
                limit: 1,
                where: {
                    id: productId
                }
            }).then(product => {
                if (!product) {
                    throw new Error(ErrorEnum.PRODUCT_NOT_FOUND);
                }
                return product;
            });
    };

    updateProduct = async (productId, product) => {
        const productDetails = db.product.findOne({
            where: { id: productId }
        });
        if (!productDetails) {
            throw new Error(ErrorEnum.PRODUCT_NOT_FOUND);
        }
        return db.product.update(product, {
            where: { id: productId }
        });
    };

    deleteProduct = async (productId) => {
        const productDetails = db.product.findOne({
            where: { id: productId }
        });
        if (!productDetails) {
            throw new Error(ErrorEnum.PRODUCT_NOT_FOUND);
        }
        return db.product.destroy({
            where: { id: productId }
        }).then(()=> {
            return true;
        });
    };
};
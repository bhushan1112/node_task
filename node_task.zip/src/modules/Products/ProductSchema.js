const { Joi, Segments } = require("celebrate");

module.exports = {
    saveProduct: {
        [Segments.BODY]: Joi.object().keys({
            productName: Joi.string().trim().required(),
            category: Joi.string().trim().required(),
            priceBand: Joi.string().trim().required()
        })
    },
    getProducts: {
        [Segments.QUERY]: {
            page: Joi.number().integer().min(1),
            size: Joi.number().integer().min(1),
            search: Joi.string().trim(),
            order: Joi.string().trim(),
            orderBy: Joi.string().trim()
        }
    },
    getProduct: {
        [Segments.PARAMS]: {
            id: Joi.number().integer().min(1).required()
        }
    },
    updateProduct: {
        [Segments.PARAMS]: {
            id: Joi.number().integer().min(1).required()
        },
        [Segments.BODY]: Joi.object().keys({
            productName: Joi.string().trim().required(),
            category: Joi.string().trim().required(),
            priceBand: Joi.string().trim().required()
        })
    },
    deleteProduct: {
        [Segments.PARAMS]: {
            id: Joi.number().integer().min(1).required()
        },
    },
};
const ProductUtils = require("./ProductUtils");
const { successResponse, errorResponse } = require("../../config");
const { SuccessEnum, ErrorEnum } = require("../../helper/messages");
const Constants = require("../../helper/constants");

const productUtils = new ProductUtils();

module.exports = class RoleController { 
    saveProduct = async (req, res) => {
        try {
            const details = await productUtils.saveProduct(req.body);
            if (details) {
                return res.json(successResponse(details, SuccessEnum.PRODUCT_CREATED, Constants.SUCCESS_CODE));
            } else {
                return res.json(errorResponse(ErrorEnum.PRODUCT_NOT_CREATED, Constants.INTERNAL_SERVER_ERROR_CODE));
            }
        } catch (error) {
            return res.json(errorResponse(error.message, Constants.INTERNAL_SERVER_ERROR_CODE));
        }
    };

    getProducts = async (req, res) => {
        try {
            const filters = req.query;
            const product = await productUtils.getProducts(filters);
            if (product) {
                return res.json(product, Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.PRODUCTS_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }   
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

    getProductById = async (req, res) => {
        try {
            const productId = req.params.id;
            const product = await productUtils.getProductById(productId);
            if (product) {
                return res.json(product, Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.PRODUCTS_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }  
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
        

    };

    updateProduct = async (req, res) => {
        try {
            const productId = req.params.id;
            const product = await productUtils.updateProduct(productId, req.body);
            if (product) {
                return res.json(SuccessEnum.PRODUCT_UPDATED ,Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.PRODUCTS_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }  
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

    deleteProduct = async (req, res) => {
        try {
            const productId = req.params.id;
            const product = await productUtils.deleteProduct(productId);
            if (product) {
                return res.json(SuccessEnum.PRODUCT_DELETE ,Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.PRODUCT_NOT_CREATED, Constants.NOT_FOUND_CODE));
            }  
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

};
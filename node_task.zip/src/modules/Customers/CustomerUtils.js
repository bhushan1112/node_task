const db = require("../../DB/index");
const { queryForSearch } = require("../../helper/common");
const { ErrorEnum } = require("../../helper/messages");

module.exports = class CustomerUtils {
    saveCustomer = async (customer) => {
        const finaleObject = {
            firstName: customer.firstName,
            lastName: customer.lastName,
            email: customer.email,
            phone: customer.phone,
            city: customer.city,
            userId: customer._user.id
        };
        return db.customer.create(finaleObject).then((res) => {
            return res;
        }).catch((err => {
            throw err;
        }));
    };

    getCustomers = async (filters) => {
        if (filters.search) {
            filters.searchFields = ["firstName", "email"];
        }
        const query = await queryForSearch(filters);
        if (!query.where) {
            query.where = {};
        }
        return db.customer.findAndCountAll({
            col: "id",
            distinct: true,
            attributes: ["id", "firstName", "lastName", "email", "phone"],
            ...query
        }).then(customers => {
            if (!customers) {
                throw new Error(ErrorEnum.CUSTOMERS_NOT_FOUND);
            }
            return customers;
        });
    };
};
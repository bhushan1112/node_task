const express = require("express");

const CustomerController = require("./CustomerController");
const validate = require("../../middlewares/validate");
const CustomerSchema = require("./CustomerSchema");
const Middleware = require("../../middlewares/middleware");
const CustomerMiddleware = require("./CustomerMiddleware");


const router = express.Router();
const customerController = new CustomerController();
const middleware = new Middleware();
const customerMiddleware = new CustomerMiddleware();


router.post("/", validate(CustomerSchema.saveCustomer), middleware.getUserAuthorized,customerMiddleware.checkRole, customerController.saveCustomer);
router.get("/", validate(CustomerSchema.getSustomer),middleware.getUserAuthorized, customerMiddleware.checkRole, customerController.getCustomers);

module.exports = router;
const CustomertUtils = require("./CustomerUtils");
const { successResponse, errorResponse } = require("../../config");
const { SuccessEnum, ErrorEnum } = require("../../helper/messages");
const Constants = require("../../helper/constants");

const customerUtils = new CustomertUtils();

module.exports = class CustomerController {
    saveCustomer = async (req, res) => {
        try {
            const details = await customerUtils.saveCustomer(req.body);
            if (details) {
                return res.json(successResponse(details, SuccessEnum.CUSTOMER_CREATED, Constants.SUCCESS_CODE));
            } else {
                return res.json(errorResponse(ErrorEnum.USER_NOT_CREATED, 500));
            }
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

    getCustomers = async (req, res) => {
        try {
            console.log(req.body._user.roleId);
            const filters = req.query;
            const customer = await customerUtils.getCustomers(filters);
            if (customer) {
                return res.json(customer, Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.CUSTOMERS_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }   
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };
};
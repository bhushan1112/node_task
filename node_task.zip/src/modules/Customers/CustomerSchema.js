const { Joi, Segments } = require("celebrate");

module.exports = {
    saveCustomer: {
        [Segments.BODY]: Joi.object().keys({
            firstName: Joi.string().trim().required(),
            lastName: Joi.string().trim().required(),
            email: Joi.string().trim().required().email(),
            phone: Joi.string().trim().required(),
            city: Joi.string().trim().required(),
            country: Joi.string().trim().required()
        })
    },
    getSustomer: {
        [Segments.QUERY]: {
            page: Joi.number().integer().min(1),
            size: Joi.number().integer().min(1),
            search: Joi.string().trim(),
            order: Joi.string().trim(),
            orderBy: Joi.string().trim()
        }
    }
};
const Constants = require("../../helper/constants");
const { ErrorEnum } = require("../../helper/messages");
module.exports = class CustomerMiddleware {
    checkRole = async (
        req,
        res,
        next
    ) => {
        if(req.body._user.roleId === 1) {
            next();
        } else{
            return res
                .status(Constants.UNAUTHORIZED_CODE)
                .json({
                    error: ErrorEnum.ERR_UNAUTH,
                    code: Constants.UNAUTHORIZED_CODE,
                });
        }
    };
};
const { Joi, Segments } = require("celebrate");

module.exports = {
    signup: {
        [Segments.BODY]: {
            name: Joi.string().trim().required(),
            email: Joi.string().trim().required().email(),
            password: Joi.string().trim().required(),
            roleId: Joi.number().integer().required()
        }
    },
    login: {
        [Segments.BODY]: Joi.object().keys({
            email: Joi.string().trim().required().email(),
            password: Joi.string().trim().required()
        })
    }
};
const bcryptjs = require("bcryptjs");
const UserUtils = require("./UserUtils");
const Constants = require("../../helper/constants");
const { ErrorEnum } = require("../../helper/messages");

const userUtils = new UserUtils();
module.exports = class UserMiddleware {
    checkCredentials = async (
        req,
        res,
        next
    ) => {
        // get user detail by email address
        const user = await userUtils.checkUserEmailExists(req.body.email);
        // check credentials matches or not
        if (
            user &&
            user.id &&
            (await bcryptjs.compare(req.body.password, user.dataValues.password))
        ) {
            req.body._authentication = user.dataValues;
            next();
        } else {
            return res
                .status(Constants.UNAUTHORIZED_CODE)
                .json({
                    error: ErrorEnum.INVALID_LOGIN,
                    code: Constants.UNAUTHORIZED_CODE,
                });
        }
    };
};
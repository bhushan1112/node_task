const bcryptjs = require("bcryptjs");
const UserUtils = require("./UserUtils");
const { successResponse, errorResponse } = require("../../config");
const Constants = require("../../helper/constants");
const Jwt = require("../../helper/jwt");
const { SuccessEnum, ErrorEnum } = require("../../helper/messages");
const { validatePassword } = require("../../helper/common");

const jwt = new Jwt();

const userUtils = new UserUtils();
module.exports = class UserController {

    // sign-up user
    signup = async (req, res) => {
        try {

            if (!validatePassword(req.body.password)) {
                return res.status(Constants.FAIL_CODE).json(errorResponse(ErrorEnum.INVALID_PASSWORD, 500));
            }
            // encrypt password
            req.body.password = bcryptjs.hashSync(req.body.password.toString(), Constants.PASSWORD_HASH);

            // creating User profile
            const result = await userUtils.signup(req.body);

            if (result && result.id) {
                // JWT token
                const userDetails = {
                    token: jwt.getAuthToken({ userId: result.id }),
                    Email: req.body.email,
                    UserName: req.body.name
                };
                return res.json(successResponse(userDetails, SuccessEnum.USER_CREATED, Constants.SUCCESS_CODE)); // sending only JWT token in response
            } else {
                return res.status(Constants.FAIL_CODE).json(result); // sending error if any
            }
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

    // sign-in user
    login = async (req, res) => {
        try {
            // JWT token
            const details = {
                token: jwt.getAuthToken({
                    userId: req.body._authentication.id,
                }),
                UserName:
                    req.body._authentication.name,
                Email: req.body._authentication.email,
            };
            return res.status(Constants.SUCCESS_CODE).json(details); // sending only JWT token in response
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };
};
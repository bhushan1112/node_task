const db = require("../../DB/index");
const { ErrorEnum } = require("../../helper/messages");

module.exports = class UserUtils {
    signup = async (userDetails) => {
        const userExists = await db.users.findOne({ where: { email: userDetails.email } });
        if (userExists) {
            throw new Error(ErrorEnum.USER_EXISTS);
        }
        return db.users.create(userDetails).then((res) => {
            return res;
        }).catch((err => {
            throw err;
        }));
    };

    checkUserEmailExists = async (email) => {
        const userExists = await db.users.findOne({ where: { email: email } });
        if (!userExists) {
            throw new Error(ErrorEnum.USER_NOT_EXISTS);
        }
        return userExists;
    };
};
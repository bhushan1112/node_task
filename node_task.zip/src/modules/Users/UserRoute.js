const express = require("express");

const UserController = require("./UserController");
const UserMiddleware = require("./UserMiddleware");
const UserSchema = require("./UserSchema");
const validate = require("../../middlewares/validate");

const router = express.Router();
const userController = new UserController();
const userMiddleware = new UserMiddleware();

router.post("/signup", validate(UserSchema.signup), (req, res, next) => {
    return userController.signup(req, res).catch(err => {
        next(err);
    });
});


router.post("/login", validate(UserSchema.login),userMiddleware.checkCredentials, (req, res, next) => {
    return userController.login(req, res).catch(err => {
        next(err);
    });
});

module.exports = router;
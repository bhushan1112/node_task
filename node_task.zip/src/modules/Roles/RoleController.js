const RoleUtils = require("./RoleUtils");
const { successResponse, errorResponse } = require("../../config");
const { SuccessEnum, ErrorEnum } = require("../../helper/messages");
const Constants = require("../../helper/constants");

const roleUtils = new RoleUtils();

module.exports = class RoleController { 
    saveRole = async (req, res) => {
        try {
            const details = await roleUtils.saveRole(req.body);
            if (details) {
                return res.json(successResponse(details, SuccessEnum.ROLE_CREATED, Constants.SUCCESS_CODE));
            } else {
                return res.json(errorResponse(ErrorEnum.USER_NOT_CREATED, Constants.INTERNAL_SERVER_ERROR_CODE));
            }
        } catch (error) {
            return res.json(errorResponse(error.message, Constants.INTERNAL_SERVER_ERROR_CODE));
        }
    };

    getRoles = async (req, res) => {
        try {
            const filters = req.query;
            const customer = await roleUtils.getRoles(filters);
            if (customer) {
                return res.json(customer, Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.CUSTOMERS_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }   
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

    getRoleById = async (req, res) => {
        try {
            const roleId = req.params.id;
            const role = await roleUtils.getRoleById(roleId);
            if (role) {
                return res.json(role, Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.ROLE_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }  
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
        

    };

    updateRole = async (req, res) => {
        try {
            const roleId = req.params.id;
            const role = await roleUtils.updateRole(roleId, req.body);
            if (role) {
                return res.json(SuccessEnum.ROLE_UPDATE ,Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.ROLE_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }  
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

    deleteRole = async (req, res) => {
        try {
            const roleId = req.params.id;
            const role = await roleUtils.deleteRole(roleId);
            if (role) {
                return res.json(SuccessEnum.ROLE_DELETE ,Constants.SUCCESS_CODE);
            } else {
                return res.json(errorResponse(ErrorEnum.ROLE_NOT_FOUND, Constants.NOT_FOUND_CODE));
            }  
        } catch (error) {
            return res.json(errorResponse(error.message, 500));
        }
    };

};
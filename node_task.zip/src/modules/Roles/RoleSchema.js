const { Joi, Segments } = require("celebrate");

module.exports = {
    saveRole: {
        [Segments.BODY]: Joi.object().keys({
            role: Joi.string().trim().required()
        })
    },
    getRoles: {
        [Segments.QUERY]: {
            page: Joi.number().integer().min(1),
            size: Joi.number().integer().min(1),
            search: Joi.string().trim(),
            order: Joi.string().trim(),
            orderBy: Joi.string().trim()
        }
    },
    getRole: {
        [Segments.PARAMS]: {
            id: Joi.number().integer().min(1).required()
        }
    },
    updateRole: {
        [Segments.PARAMS]: {
            id: Joi.number().integer().min(1).required()
        },
        [Segments.BODY]: Joi.object().keys({
            role: Joi.string().trim().required()
        })
    },
    deleteRole: {
        [Segments.PARAMS]: {
            id: Joi.number().integer().min(1).required()
        },
    },
};
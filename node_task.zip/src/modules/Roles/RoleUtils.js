const db = require("../../DB/index");
const { queryForSearch } = require("../../helper/common");
const { ErrorEnum } = require("../../helper/messages");

module.exports = class RoleUtils {
    saveRole = async (role) => {
        console.log(role.role);
        const finaleObject = {
            role: role.role
        };
        console.log(finaleObject);
        return db.role.create(finaleObject).then((res) => {
            return res;
        }).catch((err => {
            console.log(err);
            throw err;
        }));
    };

    getRoles = async (filters) => {
        if (filters.search) {
            filters.searchFields = ["role"];
        }
        const query = await queryForSearch(filters);
        if (!query.where) {
            query.where = {};
        }
        return db.role.findAndCountAll({
            col: "id",
            distinct: true,
            attributes: ["id", "role"],
            ...query
        }).then(roles => {
            if (!roles) {
                throw new Error(ErrorEnum.ROLES_NOT_FOUND);
            }
            return roles;
        });
    };

    getRoleById = async (roleId) => {
        return db.role
            .findOne({
                attributes: ["id", "role"],
                order: [
                    ["id", "desc"]
                ],
                limit: 1,
                where: {
                    id: roleId
                }
            }).then(role => {
                if (!role) {
                    throw new Error(ErrorEnum.ROLE_NOT_FOUND);
                }
                return role;
            });
    };

    updateRole = async (roleId, role) => {
        const roleDetails = db.role.findOne({
            where: { id: roleId }
        });
        if (!roleDetails) {
            throw new Error(ErrorEnum.ROLE_NOT_FOUND);
        }
        return db.role.update(role, {
            where: { id: roleId }
        });
    };

    deleteRole = async (roleId) => {
        const roleDetails = db.role.findOne({
            where: { id: roleId }
        });
        if (!roleDetails) {
            throw new Error(ErrorEnum.ROLE_NOT_FOUND);
        }
        return db.role.destroy({
            where: { id: roleId }
        }).then(()=> {
            return true;
        });
    };
};
const express = require("express");

const validate = require("../../middlewares/validate");
const RoleSchema = require("./RoleSchema");
const Middleware = require("../../middlewares/middleware");
const RoleController = require("./RoleController");

const router = express.Router();
const middleware = new Middleware();
const roleController = new RoleController();

router.post("/", validate(RoleSchema.saveRole), middleware.getUserAuthorized, roleController.saveRole);
router.get("/", validate(RoleSchema.getRoles),middleware.getUserAuthorized, roleController.getRoles);
router.get("/:id", validate(RoleSchema.getRole),middleware.getUserAuthorized, roleController.getRoleById);
router.put("/:id", validate(RoleSchema.updateRole),middleware.getUserAuthorized, roleController.updateRole);
router.delete("/:id", validate(RoleSchema.deleteRole),middleware.getUserAuthorized, roleController.deleteRole);

module.exports = router;
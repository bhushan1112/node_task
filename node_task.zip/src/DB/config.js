/* eslint-disable no-undef */
module.exports = {
    host: process.env.DBHOST || "localhost",
    user: process.env.DBUSER || "user",
    password: process.env.DBPASSWORD || "Bhushan@1415",
    database: process.env.DATABASE || "task",
    dialect: "mysql",
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }
};
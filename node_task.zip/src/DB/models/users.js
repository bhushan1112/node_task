module.exports = (sequelize, DataTypes) => {
    const users = sequelize.define(
      "users",
      {
        id: {
          type: DataTypes.INTEGER,
          allowNull: false,
          primaryKey: true,
          autoIncrement: true,
        },
        name: {
          type: DataTypes.STRING(50),
          allowNull: false,
          field: "name",
        },
        email: {
          type: DataTypes.STRING(255),
          allowNull: false,
          field: "email"
        },
        password: {
          type: DataTypes.STRING(255),
          allowNull: false,
          field: "password",
        },
        roleId: {
          type: DataTypes.INTEGER(11),
          references: {
              model: "role",
              key: "id",
          },
          allowNull: false,
          field: "roleId",
      },
      },
      {
        tableName: "users",
        timestamps: true
      }
    );
    users.associate = (models) => {
      users.belongsTo(models.role, { as: "role", foreignKey: "roleId" });
      users.hasMany(models.customer, {
          as: "customer",
          foreignKey: "userId",
      });
  };
    return users;
  };
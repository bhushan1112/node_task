module.exports = (sequelize, DataTypes) => {
    const product = sequelize.define(
        "product",
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true,
            },
            productName: {
                type: DataTypes.STRING(50),
                allowNull: false,
                field: "productName",
            },
            category: {
                type: DataTypes.STRING(50),
                allowNull: false,
                field: "category",
            },
            priceBand: {
                type: DataTypes.STRING(50),
                allowNull: false,
                field: "priceBand",
            },
        },
        {
            tableName: "product",
            timestamps: true
        }
    );
    return product;
};
module.exports = (sequelize, DataTypes) => {
    const customer = sequelize.define(
        "customer",
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true,
            },
            firstName: {
                type: DataTypes.STRING(50),
                allowNull: false,
                field: "firstName",
            },
            lastName: {
                type: DataTypes.STRING(50),
                allowNull: false,
                field: "lastName",
            },
            email: {
                type: DataTypes.STRING(255),
                allowNull: false,
                field: "email"
            },
            phone: {
                type: DataTypes.STRING(255),
                allowNull: false,
                field: "phone",
            },
            city: {
                type: DataTypes.STRING(255),
                allowNull: false,
                field: "city",
            },
            userId: {
                type: DataTypes.INTEGER(11),
                references: {
                    model: "users",
                    key: "id",
                },
                allowNull: false,
                field: "userId",
            },
        },
        {
            tableName: "customer",
            timestamps: true
        },
    );
    customer.associate = (models) => {
        customer.belongsTo(models.users, { as: "users", foreignKey: "userId" });
    };
    return customer;
};
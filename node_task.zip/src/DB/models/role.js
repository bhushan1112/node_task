module.exports = (sequelize, DataTypes) => {
    const role = sequelize.define(
      "role",
      {
        id: {
          type: DataTypes.INTEGER,
          allowNull: false,
          primaryKey: true,
          autoIncrement: true,
        },
        role: {
          type: DataTypes.STRING(50),
          allowNull: false,
          field: "role",
        },
      },
      {
        tableName: "role",
        timestamps: true
      }
    );
    return role;
  };
const SuccessEnum = Object.freeze({
    USER_CREATED: "User created successfully.",
    CUSTOMER_CREATED: "Customer created successfully.",
    ROLE_CREATED: "Role created successfully.",
    ROLE_UPDATE: "Role updated successfully.",
    ROLE_DELETE: "Role deleted successfully.",
    PRODUCT_CREATED: "Product created successfully.",
    PRODUCT_UPDATED: "Product updated successfully.",
    PRODUCT_DELETE: "Product deleted successfully.",
});

const ErrorEnum = Object.freeze({
    USER_EXISTS: "User already exists.",
    INVALID_PASSWORD: "Password should be atleast 8 characters with minimum one uppercase and lowercase character and also include any special character [@_!$*#%].",
    INVALID_LOGIN: "Email or password is incorrect.",
    ERR_INTERNAL_SERVER: "Internal server error",
    ERR_UNAUTH: "Unauthorized",
    ERR_URL_NOT_FOUND: "URL not found",
    USER_NOT_CREATED: "User not found",
    CUSTOMERS_NOT_FOUND: "Customers not found",
    ROLES_NOT_FOUND: "Roles not found",
    ROLE_NOT_FOUND: "Role not found",
    PRODUCTS_NOT_FOUND: "Products not found",
    PRODUCT_NOT_FOUND: "Product not found",
    PRODUCT_NOT_CREATED: "Product not created",
});

module.exports = { ErrorEnum, SuccessEnum };
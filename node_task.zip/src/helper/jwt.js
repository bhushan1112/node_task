/* eslint-disable no-undef */
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
dotenv.config();

module.exports = class Jwt {
  /*
  * getAuthToken
  */
getAuthToken(data) {
    return jwt.sign(data.userId, process.env.JWT_SECRET);
}

  /*
  * decodeAuthToken
  */
decodeAuthToken(token) {
    if (token) {
      try {
        return jwt.verify(token, process.env.JWT_SECRET);
      } catch (error) {
        return false;
      }
    }
    return false;
  }
};
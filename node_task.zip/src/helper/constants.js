module.exports = class Constants {
  static TIMEZONE = "Asia/Kolkata";

  static PASSWORD_HASH = 12;
  static DATE_TIME_FORMAT = "YYYY-MM-DD hh:mm:ss";

  static UNAUTHORIZED_CODE = 401;
  static NOT_FOUND_CODE = 404;
  static SUCCESS_CODE = 200;
  static INTERNAL_SERVER_ERROR_CODE = 500;
  static FAIL_CODE = 400;

  static SERVER_STARTS = "The server is running in port localhost:";

  static regex = new RegExp(
    "^(?!.* )(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[@_!$*#%]).{8,30}$"
  );

  static RECORDS_PER_PAGE = 10;
};
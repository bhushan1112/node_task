const { Op } = require("sequelize");

const validatePassword = (password) => {
  const regex = new RegExp(
    "^(?!.* )(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[@_!$*#%]).{8,30}$"
  );
  return regex.test(password);
};


const queryForSearch = params => {
  const query = {};

  query.limit = parseInt(params.size, 10) || 1000;
  params.page = parseInt(params.page, 10) || 1;
  query.offset = (params.page - 1) * query.limit;
  query.order = [[params.orderBy || "createdAt", params.order || "DESC"]];

  let whereObj = {};
  let isWhereAdd = false;
  if (params.searchFields) {
    const condition = [];
    for (let i = 0; i < params.searchFields.length; i += 1) {
      condition.push({
        [params.searchFields[i]]: { [Op.like]: `%${params.search}%` }
      });
    }
    whereObj = { [Op.or]: condition };
    isWhereAdd = true;
  }

  if (isWhereAdd) {
    query.where = whereObj;
  }
  return query;
};

module.exports = {
  queryForSearch,
  validatePassword
};

const successResponse = (data, message = "SUCCESS", code = 200) => {
    return {
      code,
      message,
      data
    };
  };
  
  const errorResponse = (message, code = 500) => {
    return {
      code,
      message
    };
  };
  
  module.exports = {
    successResponse,
    errorResponse
  };
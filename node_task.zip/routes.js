const express = require("express");

const UserRoute = require("./src/modules/Users/UserRoute");
const CustomerRoute = require("./src/modules/Customers/CustomerRoute");
const RoleRoute = require("./src/modules/Roles/RoleRoute");
const ProductRoute = require("./src/modules/Products/ProductRoute");
const { ErrorEnum } = require("./src/helper/messages");
const Constants = require("./src/helper/constants");

module.exports = class Routes {
  path() {
    const router = express.Router();

    router.use("/user", UserRoute);
    router.use("/customer", CustomerRoute);
    router.use("/role", RoleRoute);
    router.use("/product", ProductRoute);

    router.all("/*", (req, res) => {
      return res.status(Constants.NOT_FOUND_CODE).json({
        error: ErrorEnum.ERR_URL_NOT_FOUND,
      });
    });
    return router;
  }
};